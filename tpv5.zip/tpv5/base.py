import startpage

def start():
    startpage.runStartPage()

start()